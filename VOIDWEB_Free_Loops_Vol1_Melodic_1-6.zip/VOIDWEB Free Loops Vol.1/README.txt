VOIDWEB FREE LOOPS VOL.1
========================
12 melodic loops · 4 drum loops (808 + drums) · 8 one-shots
WAV 44.1 kHz / 16-bit · 140 and 150 BPM · key and BPM are in every file name

Every sound in this pack comes straight out of VOIDWEB, a dark cosmic synth for FL Studio:
50 synths in 5 worlds, the ORACLE melody + 808 drum generator, and a pixel cosmic web
that plays along with your sound. No extra processing.

The loops are seamless: drop them on the playlist at the BPM in the file name.
Drum loops have the 808 tuned to the key in the name.

Get VOIDWEB:            https://sashakhristenko-source.github.io/voidweb/
Launch week -30% until Nov 15, 2026 with code LAUNCH:
                        https://sashahristenko.gumroad.com/l/voidweb/LAUNCH

Made something with these? Tag it "prod. w/ VOIDWEB", we'd love to hear it.
