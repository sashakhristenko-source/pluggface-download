@echo off
chcp 65001 >nul
rem Installs PluggFace.vst3 into the system VST3 folder, which needs admin rights.

net session >nul 2>&1
if errorlevel 1 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set "SRC=%~dp0PluggFace.vst3"
set "DEST=%CommonProgramFiles%\VST3"

if not exist "%SRC%" (
    echo Рядом с этим файлом нет папки PluggFace.vst3. Сначала распакуй архив целиком.
    pause
    exit /b 1
)

if not exist "%DEST%" mkdir "%DEST%"
if exist "%DEST%\PluggFace.vst3" rmdir /s /q "%DEST%\PluggFace.vst3"
xcopy "%SRC%" "%DEST%\PluggFace.vst3\" /e /i /y /q >nul
if errorlevel 1 (
    echo Не получилось скопировать плагин в %DEST%
    pause
    exit /b 1
)

echo.
echo Готово! PluggFace установлен в %DEST%
echo Теперь открой FL Studio: Options - Manage plugins - Find installed plugins.
echo.
pause
