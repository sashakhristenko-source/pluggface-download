@echo off
chcp 65001 >nul
rem Installs VOIDWEB (single-file VST3, 64-bit and 32-bit) into the system VST3 folders.
rem Works with FL Studio 12 and newer. Uses goto instead of ( ) blocks because the
rem "Program Files (x86)" path would break block parsing.

net session >nul 2>&1
if not errorlevel 1 goto :admin
powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
exit /b

:admin
set "HERE=%~dp0"
set "DEST64="
set "DEST32=%CommonProgramFiles%\VST3"
if not exist "%SystemRoot%\SysWOW64" goto :paths_done
set "DEST64=%CommonProgramW6432%\VST3"
set "DEST32=%CommonProgramFiles(x86)%\VST3"
:paths_done

set "FAILED=0"
if defined DEST64 call :install "%HERE%64-bit\VOIDWEB.vst3" "%DEST64%"
call :install "%HERE%32-bit\VOIDWEB.vst3" "%DEST32%"

echo.
if "%FAILED%"=="1" goto :done
echo Готово! VOIDWEB установлен для 64-bit и 32-bit FL Studio.
echo Теперь открой FL Studio и обнови список плагинов (см. КАК УСТАНОВИТЬ.txt).
:done
echo.
pause
exit /b 0

:install
if not exist "%~1" goto :missing
if not exist "%~2" mkdir "%~2"
if exist "%~2\VOIDWEB.vst3\" rmdir /s /q "%~2\VOIDWEB.vst3"
copy /y "%~1" "%~2\VOIDWEB.vst3" >nul
if errorlevel 1 goto :copy_failed
echo Установлено: %~2\VOIDWEB.vst3
exit /b 0

:missing
echo Не найден файл: %~1
echo Сначала распакуй архив целиком.
set "FAILED=1"
exit /b 1

:copy_failed
echo Не получилось скопировать в: %~2
set "FAILED=1"
exit /b 1
